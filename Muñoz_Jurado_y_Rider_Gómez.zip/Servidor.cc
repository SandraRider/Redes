/**
 * @file Servidor.cc
 * @author Laura Muñoz Jurado y Sandra Rider Gómez
 * @brief Servidor de un sistema de juego de cartas BlackJack.
 * @date 2024
 *
 * El servidor gestiona las conexiones de los clientes para un juego de cartas BlackJack.
 * Los jugadores pueden registrarse, iniciar sesión, jugar partidas y solicitar cartas.
 * El servidor acepta múltiples conexiones hasta un máximo de 30 clientes.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>
#include <arpa/inet.h>
#include <vector>

#include "Servidor.hpp"

#define MSG_SIZE 250   // El tamaño máximo envío una cadena de longitud 250 caracteres
#define MAX_CLIENTS 30 // El número máximo de clientes conectados será de 30 usuarios

using namespace std;

/**
 * @fn void manejador(int signum)
 * @brief Manejador de la señal SIGINT.
 *
 * Se activa cuando el servidor recibe la señal SIGINT (Ctrl+c). Permite manejar la salida
 * controlada del servidor cerrando todas las conexiones abiertas.
 *
 * @param signum Número de la señal recibida.
 * @return void No retorna nada.
 */
void manejador(int signum);

/**
 * @fn void salirCliente(int socket, fd_set *readfds, int *numClientes, int arrayClientes[])
 * @brief Elimina a un cliente del servidor.
 *
 * Se encarga de eliminar a un cliente y actualizar el número de clientes conectados. Cierra
 * el socket del cliente y lo elimina del array de clientes.
 *
 * @param socket Descriptor del socket del cliente.
 * @param readfds Conjunto de descriptores de socket.
 * @param numClientes Puntero al número de clientes conectados.
 * @param arrayClientes Array de clientes conectados.
 * @return void No retorna nada.
 */
void salirCliente(int socket, fd_set *readfds, int *numClientes, int arrayClientes[]);

/**
 * @fn int main()
 * @brief Función principal del servidor.
 *
 * Se encarga de iniciar el servidor, aceptar conexiones de los clientes y gestionar
 * la comunicación entre ellos. Los clientes pueden realizar operaciones como registrarse,
 * iniciar sesión, unirse a partidas de BlackJack, pedir cartas o salir del servidor.
 *
 * @return int
 */
int main()
{
    srand(time(0)); // Inicializa el generador de números aleatorios

    int sd, new_sd;
    struct sockaddr_in sockname, from;
    char buffer[MSG_SIZE];
    socklen_t from_len;
    fd_set readfds, auxfds;
    int salida;
    int arrayClientes[MAX_CLIENTS];
    int numClientes = 0;
    int i, j, k; // Contadores
    int recibidos;
    char identificador[MSG_SIZE];

    int on, ret;

    vector<struct jugadores> vjugadores;
    vector<struct partidas> vpartidas;
    vector<struct barajas> vbaraja;

    sd = socket(AF_INET, SOCK_STREAM, 0);
    if (sd == -1)
    {
        perror("No se puede abrir el socket cliente\n");
        exit(1);
    }

    on = 1;
    ret = setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

    sockname.sin_family = AF_INET;
    sockname.sin_port = htons(2060); // El servidor aceptará servicios en el puerto 2060
    sockname.sin_addr.s_addr = INADDR_ANY;

    if (bind(sd, (struct sockaddr *)&sockname, sizeof(sockname)) == -1)
    {
        perror("Error en la operación bind");
        exit(1);
    }

    from_len = sizeof(from);

    if (listen(sd, 1) == -1)
    {
        perror("Error en la operación de listen");
        exit(1);
    }

    printf("El servidor de BlackJack está esperando conexiones...\n"); // Inicializar los conjuntos fd_set

    FD_ZERO(&readfds);
    FD_ZERO(&auxfds);
    FD_SET(sd, &readfds);
    FD_SET(0, &readfds);

    // Capturamos la señal SIGINT del servidor (Ctrl+c)
    signal(SIGINT, manejador);

    /*----------------------------------------------------------------------------------------------------------------------------------------*/
    /* BUCLE DEL SERVIDOR PARA ACEPTAR PETICIONES */
    /*----------------------------------------------------------------------------------------------------------------------------------------*/
    while (1)
    {

        // Esperamos recibir mensajes de los clientes (nuevas conexiones o mensajes de los clientes ya conectados)
        auxfds = readfds;

        salida = select(FD_SETSIZE, &auxfds, NULL, NULL, NULL);

        if (salida > 0)
        {
            for (i = 0; i < FD_SETSIZE; i++)
            {
                // Buscamos el socket por el que se ha establecido la comunicación
                if (FD_ISSET(i, &auxfds))
                {
                    if (i == sd)
                    {
                        if ((new_sd = accept(sd, (struct sockaddr *)&from, &from_len)) == -1)
                        {
                            perror("Error aceptando peticiones");
                        }
                        else
                        {
                            if (numClientes < MAX_CLIENTS)
                            {
                                arrayClientes[numClientes] = new_sd;
                                numClientes++;
                                FD_SET(new_sd, &readfds);

                                strcpy(buffer, "Bienvenido al servidor de BlackJack:");

                                printf("Cliente <%d> conectado.\n", new_sd);

                                send(new_sd, buffer, sizeof(buffer), 0);

                                bzero(buffer, sizeof(buffer));
                                sprintf(buffer, "------------------ OPCIONES ------------------\nUSUARIO usuario\nPASSWORD contraseña\nREGISTRO -u usuario -p contraseña\nINICIAR-PARTIDA\nPEDIR-CARTA\nPLANTARME\nSALIR\n----------------------------------------------\n");
                                send(new_sd, buffer, sizeof(buffer), 0);
                            }
                            else
                            {
                                bzero(buffer, sizeof(buffer));
                                strcpy(buffer, "Demasiados clientes conectados\n");
                                send(new_sd, buffer, sizeof(buffer), 0);
                                close(new_sd);
                            }
                        }
                    }
                    else if (i == 0)
                    {
                        /*----------------------------------------------------------------------------------------------------------------------------------------*/
                        /* SALIR POR PARTE DEL SERVIDOR */
                        /*----------------------------------------------------------------------------------------------------------------------------------------*/

                        // Se ha introducido información de teclado
                        bzero(buffer, sizeof(buffer));
                        fgets(buffer, sizeof(buffer), stdin);

                        // Controlar si se ha introducido "SALIR", cerrando todos los sockets y finalmente saliendo del servidor
                        if (strcmp(buffer, "SALIR\n") == 0)
                        {
                            bzero(buffer, sizeof(buffer));
                            strcpy(buffer, "El servidor de BlackJack se ha apagado.\n");

                            for (j = 0; j < numClientes; j++)
                            {
                                send(arrayClientes[j], buffer, sizeof(buffer), 0);
                                salirCliente(arrayClientes[j], &readfds, &numClientes, arrayClientes);
                            }

                            printf("Servidor apagado correctamente.\n");
                            close(sd);
                            exit(0);
                        }
                    }

                    else
                    {
                        bzero(buffer, sizeof(buffer));

                        recibidos = recv(i, buffer, sizeof(buffer), 0);

                        if (recibidos > 0)
                        {
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* SALIR POR PARTE DEL CLIENTE */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            if (strcmp(buffer, "SALIR\n") == 0)
                            {

                                int estadoJugador = 0;
                                // Mira el estado del jugador (si esta en una partida jugando)
                                for (int a = 0; a < vjugadores.size(); a++)
                                {
                                    if (vjugadores[a].identificadorUsuario == i)
                                    {
                                        estadoJugador = vjugadores[a].estado;
                                    }
                                }

                                if (estadoJugador == 4) // Si el jugador esta en una partida
                                {
                                    int idJugador2 = 0;
                                    for (int h = 0; h < vpartidas.size(); h++)
                                    {
                                        if (vpartidas[h].jugador1.identificadorUsuario == i)
                                        {
                                            idJugador2 = vpartidas[h].jugador2.identificadorUsuario;
                                        }
                                        else if (vpartidas[h].jugador2.identificadorUsuario == i)
                                        {
                                            idJugador2 = vpartidas[h].jugador1.identificadorUsuario;
                                        }
                                    }
                                    // Avisa al otro jugador de que se ha salido de la partida
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "+Ok. Tu oponente ha terminado la partida");
                                    send(idJugador2, buffer, sizeof(buffer), 0);

                                    // Elimina a ambos jugadores de la partida
                                    eliminaJugadoresPartida(vjugadores, i, idJugador2, vpartidas, vbaraja);
                                }
                                else if (estadoJugador == 3)
                                {
                                    // Elimina al jugador de la lista de espera
                                    eliminaJugador(vjugadores, i, vpartidas, vbaraja);
                                }

                                salirCliente(i, &readfds, &numClientes, arrayClientes);
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* INICIAR SESIÓN USUARIO (INTRODUCE EL USUARIO Y SI HAY HUECO LO INTRODUCE EN EL VECTOR) */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "USUARIO ", strlen("USUARIO ")) == 0)
                            {
                                // Cojo el nombre del usuario
                                char jugador[250];
                                sscanf(buffer, "USUARIO %s", jugador);
                                int introducir = IntroducirUsuarioRegistrado(vjugadores, i, jugador);

                                if (introducir == 3) // El usuario es correcto y se ha introducido el juagdor en el vector
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "+OK. USUARIO correcto.");
                                    send(i, buffer, sizeof(buffer), 0);

                                    printf("Cliente <%d> conectado con usuario correctamente.\n", i);
                                }
                                else if (introducir == 2) // El usuario que ha introducido el jugador es incorrecto
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. USUARIO incorrecto.");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                                else if (introducir == 1) // No hay espacio en el vector para que se introduzca
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. Demasiados clientes conectados.");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* INTRODUCIR CONTRASEÑA */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "PASSWORD ", strlen("PASSWORD ")) == 0)
                            {

                                char contrasena[250];
                                sscanf(buffer, "PASSWORD %s", contrasena);

                                if (IntroducirContraseña(vjugadores, i, contrasena) == true) // La contraseña es correcta y se actualiza el estado a 2
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "+OK. Usuario validado");
                                    send(i, buffer, sizeof(buffer), 0);

                                    printf("Cliente <%d> conectado con contraseña correctamente.\n", i);
                                }
                                else // La contraseña que ha introducido el jugador es incorrecta
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. Error en la validacion");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* REGISTRARSE UN USUARIO NUEVO (METERLO EN EL FICHERO DE TEXTO) */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "REGISTRO ", strlen("REGISTRO ")) == 0)
                            {

                                char contrasena[250];
                                char usuario[250];
                                sscanf(buffer, "REGISTRO -u %s -p %s", usuario, contrasena);

                                if (RegistrarJugadorFichero(usuario, contrasena) == true) // El usuario ha sido registrado en el fichero de texto
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "+OK. Usuario registrado correctamente");
                                    send(i, buffer, sizeof(buffer), 0);

                                    printf("Cliente <%d> registrado correctamente.\n", i);
                                }
                                else // El usuario introducido ya esta en el fichero de texto
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. El nombre de usuario ya ha sido utilizado");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* INICIAR PARTIDA -> el usuario solicita jugar una partida de blackjack */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "INICIAR-PARTIDA", strlen("INICIAR-PARTIDA")) == 0)
                            {
                                // Comprobamos que el jugador está logueado en el servidor con su usuario y contraseña
                                bool conectado = false;
                                conectado = ConectadoConUsuarioYContraseña(vjugadores, i);

                                if (conectado)
                                {
                                    int aux, j, b;

                                    aux = meterJugadorEnPartida(vjugadores, i, vpartidas, vbaraja, &j, &b);

                                    printf("Cliente <%d> buscando partida.\n", i);

                                    if (aux == 1) // El jugador ha encontrado partida
                                    {
                                        printf("Los clientes <%d> y <%d> han encontrado partida.\n", i, j);

                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "+Ok. Empieza la partida.\n-> Repartiendo cartas...");
                                        send(i, buffer, sizeof(buffer), 0);

                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "+Ok. Empieza la partida.\n-> Repartiendo cartas...");
                                        send(j, buffer, sizeof(buffer), 0);

                                        // Asignamos las cartas al jugador 1
                                        asignarCarta(vjugadores, i, vbaraja, b);
                                        asignarCarta(vjugadores, i, vbaraja, b);

                                        // Decirle al jugador 1 que cartas tiene
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Tus cartas son:");
                                        send(i, buffer, sizeof(buffer), 0);

                                        for (int l = 0; l < vjugadores.size(); l++)
                                        {
                                            if (vjugadores[l].identificadorUsuario == i)
                                            {
                                                for (int c = 0; c < vjugadores[l].cartas.size(); c++)
                                                {
                                                    bzero(buffer, sizeof(buffer));
                                                    sprintf(buffer, "\t%s", vjugadores[l].cartas[c].c_str());
                                                    send(i, buffer, sizeof(buffer), 0);
                                                }
                                            }
                                        }
                                        // Decirle al jugador 1 la suma de las cartas que tiene
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Suma de tus cartas: %d", calcularSuma(vjugadores, i));
                                        send(i, buffer, sizeof(buffer), 0);

                                        // Asignamos las cartas al jugador 2
                                        asignarCarta(vjugadores, j, vbaraja, b);
                                        asignarCarta(vjugadores, j, vbaraja, b);

                                        // Decirle al jugador 2 que cartas tiene
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Tus cartas son:");
                                        send(j, buffer, sizeof(buffer), 0);

                                        for (int l = 0; l < vjugadores.size(); l++)
                                        {
                                            if (vjugadores[l].identificadorUsuario == j)
                                            {
                                                for (int c = 0; c < vjugadores[l].cartas.size(); c++)
                                                {
                                                    bzero(buffer, sizeof(buffer));
                                                    sprintf(buffer, "\t%s", vjugadores[l].cartas[c].c_str());
                                                    send(j, buffer, sizeof(buffer), 0);
                                                }
                                            }
                                        }

                                        // Decirle al jugador 2 la suma de las cartas que tiene
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Suma de tus cartas: %d", calcularSuma(vjugadores, j));
                                        send(j, buffer, sizeof(buffer), 0);

                                        // Decirle al jugador 1 la primera carta del jugador 2
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Tu oponente ha recibido la carta:");
                                        send(i, buffer, sizeof(buffer), 0);
                                        for (int l = 0; l < vjugadores.size(); l++)
                                        {
                                            if (vjugadores[l].identificadorUsuario == j)
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "\t%s", vjugadores[l].cartas[0].c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                            }
                                        }

                                        // Decirle al jugador 2 la primera carta del jugador 1
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-> Tu oponente ha recibido la carta:");
                                        send(j, buffer, sizeof(buffer), 0);
                                        for (int l = 0; l < vjugadores.size(); l++)
                                        {
                                            if (vjugadores[l].identificadorUsuario == i)
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "\t%s", vjugadores[l].cartas[0].c_str());
                                                send(j, buffer, sizeof(buffer), 0);
                                            }
                                        }

                                        if (calcularSuma(vjugadores, i) == 21) // BLACKJACK del jugador 1
                                        {
                                            bzero(buffer, sizeof(buffer));
                                            sprintf(buffer, "-> ¡BLACKJACK!");
                                            send(i, buffer, sizeof(buffer), 0);
                                        }
                                        if (calcularSuma(vjugadores, j) == 21) // BLACKJACK del jugador 2
                                        {
                                            bzero(buffer, sizeof(buffer));
                                            sprintf(buffer, "-> ¡BLACKJACK!");
                                            send(j, buffer, sizeof(buffer), 0);
                                        }
                                    }
                                    else if (aux == 2) // El jugador está esperando a otro
                                    {
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "+Ok. Esperando otro jugador");
                                        send(i, buffer, sizeof(buffer), 0);
                                    }
                                    else if (aux == 0) // Hay más de 10 partidas activas
                                    {
                                        printf("Cliente <%d> ha dejado de buscar partida. Se ha alcanzado el máximo de clientes jugando simultáneamente.\n", i);

                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-ERR. Demasiados clientes jugando al BlackJack.");
                                        send(i, buffer, sizeof(buffer), 0);
                                    }
                                }
                                else if (!conectado)
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. No puedes iniciar partida sin antes loguearte.");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* PEDIR CARTA -> el usuario pide una nueva carta si no ha superado los 21 puntos */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "PEDIR-CARTA", strlen("PEDIR-CARTA")) == 0)
                            {
                                // Comprobamos que el jugador está logueado en el servidor con su usuario y contraseña
                                bool conectado = false;
                                conectado = ConectadoConUsuarioYContraseña(vjugadores, i);

                                if (conectado) // Si el jugador está logueado
                                {
                                    bool turnoJugador, plantadoJugador;
                                    int estadoJugador = 0;
                                    // Mira el turno del jugador
                                    for (int a = 0; a < vjugadores.size(); a++)
                                    {
                                        if (vjugadores[a].identificadorUsuario == i)
                                        {
                                            estadoJugador = vjugadores[a].estado;
                                            turnoJugador = vjugadores[a].turno;
                                            plantadoJugador = vjugadores[a].plantado;
                                        }
                                    }

                                    if (estadoJugador == 4) // Si el jugador ha iniciado una partida
                                    {
                                        if (!plantadoJugador) // Si el jugador no se ha plantado (plantado = false)
                                        {
                                            if (turnoJugador) // Si es el turno del jugador (turno = true)
                                            {
                                                int idbaraja = 0, idJugador2 = 0;
                                                bool plantadoJugador2;
                                                for (int h = 0; h < vpartidas.size(); h++)
                                                {
                                                    if (vpartidas[h].jugador1.identificadorUsuario == i)
                                                    {
                                                        idbaraja = vpartidas[h].baraja.identificadorBaraja;
                                                        idJugador2 = vpartidas[h].jugador2.identificadorUsuario;
                                                        plantadoJugador2 = vpartidas[h].jugador2.plantado;
                                                    }
                                                    else if (vpartidas[h].jugador2.identificadorUsuario == i)
                                                    {
                                                        idbaraja = vpartidas[h].baraja.identificadorBaraja;
                                                        idJugador2 = vpartidas[h].jugador1.identificadorUsuario;
                                                        plantadoJugador2 = vpartidas[h].jugador1.plantado;
                                                    }
                                                }

                                                for (int l = 0; l < vjugadores.size(); l++)
                                                {
                                                    if (vjugadores[l].identificadorUsuario == i)
                                                    {
                                                        if (calcularSuma(vjugadores, i) < 21) // El jugador puede pedir cartas
                                                        {
                                                            asignarCarta(vjugadores, i, vbaraja, idbaraja);

                                                            // Decirle al jugador que cartas tiene
                                                            bzero(buffer, sizeof(buffer));
                                                            sprintf(buffer, "-> Tus cartas son:");
                                                            send(i, buffer, sizeof(buffer), 0);
                                                            // Imprime las cartas del jugador
                                                            for (int c = 0; c < vjugadores[l].cartas.size(); c++)
                                                            {
                                                                bzero(buffer, sizeof(buffer));
                                                                sprintf(buffer, "\t%s", vjugadores[l].cartas[c].c_str());
                                                                send(i, buffer, sizeof(buffer), 0);
                                                            }
                                                            // Imprime la suma de las cartas del jugador
                                                            bzero(buffer, sizeof(buffer));
                                                            sprintf(buffer, "-> Suma de tus cartas: %d", calcularSuma(vjugadores, i));
                                                            send(i, buffer, sizeof(buffer), 0);
                                                        }
                                                        else if (calcularSuma(vjugadores, i) == 21) // El jugador no puede pedir más cartas, ya tiene 21 puntos
                                                        {
                                                            bzero(buffer, sizeof(buffer));
                                                            sprintf(buffer, "-ERR. No puedes pedir más cartas, ya que tu suma es igual a 21.");
                                                            send(i, buffer, sizeof(buffer), 0);
                                                        }
                                                        else if (calcularSuma(vjugadores, i) > 21) // El jugador no puede pedir más cartas, se ha pasado de 21 puntos
                                                        {
                                                            bzero(buffer, sizeof(buffer));
                                                            sprintf(buffer, "-ERR. Excedido el valor de 21.");
                                                            send(i, buffer, sizeof(buffer), 0);
                                                        }
                                                    }
                                                }
                                            }
                                            else if (!turnoJugador) // Si no es el turno del jugador (turno = false)
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "-ERR. Turno del jugador contrario. Espera al otro jugador.");
                                                send(i, buffer, sizeof(buffer), 0);
                                            }
                                        }
                                        else if (plantadoJugador) // Si el jugador se ha plantado
                                        {
                                            bzero(buffer, sizeof(buffer));
                                            sprintf(buffer, "-ERR. No puedes pedir carta. Te has plantado.");
                                            send(i, buffer, sizeof(buffer), 0);
                                        }
                                    }
                                    else if (estadoJugador != 4) // Si el jugador no ha iniciado una partida
                                    {
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-ERR. No puedes pedir carta sin antes iniciar partida.");
                                        send(i, buffer, sizeof(buffer), 0);
                                    }
                                }
                                else // Si el jugador no está logueado
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. No puedes pedir carta sin antes loguearte.");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* PLANTARME -> el usuario indica que ya no quiere más cartas y se planta con las que tiene */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else if (strncmp(buffer, "PLANTARME", strlen("PLANTARME")) == 0)
                            {
                                // Comprobamos que el jugador está logueado en el servidor con su usuario y contraseña
                                bool conectado = false;
                                conectado = ConectadoConUsuarioYContraseña(vjugadores, i);

                                if (conectado) // El usuario esta logueado
                                {
                                    int estadoJugador = 0;
                                    // Mira el estado del jugador (si esta en una partida jugando)
                                    for (int a = 0; a < vjugadores.size(); a++)
                                    {
                                        if (vjugadores[a].identificadorUsuario == i)
                                        {
                                            estadoJugador = vjugadores[a].estado;
                                        }
                                    }

                                    if (estadoJugador == 4) // Si el jugador esta en una partida
                                    {
                                        int idJugador2 = 0;
                                        for (int h = 0; h < vpartidas.size(); h++)
                                        {
                                            if (vpartidas[h].jugador1.identificadorUsuario == i)
                                            {
                                                idJugador2 = vpartidas[h].jugador2.identificadorUsuario;
                                            }
                                            else if (vpartidas[h].jugador2.identificadorUsuario == i)
                                            {
                                                idJugador2 = vpartidas[h].jugador1.identificadorUsuario;
                                            }
                                        }

                                        // Cambia el jugador a plantado (plantado = true) y cambia el turno del otro jugador a true
                                        for (int a = 0; a < vjugadores.size(); a++)
                                        {
                                            if (vjugadores[a].identificadorUsuario == i) // El jugador 1 se planta
                                            {
                                                vjugadores[a].plantado = true;
                                                vjugadores[a].turno = false;

                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Te has plantado.");
                                                send(i, buffer, sizeof(buffer), 0);
                                            }
                                            else if (vjugadores[a].identificadorUsuario == idJugador2) // El jugador 2 puede seguir jugando
                                            {
                                                vjugadores[a].turno = true;
                                            }
                                        }

                                        int aux = 0; // Auxiliar para comprobar si se han plantado los dos
                                        for (int a = 0; a < vjugadores.size(); a++)
                                        {
                                            if ((vjugadores[a].identificadorUsuario == i) && (vjugadores[a].plantado))
                                                aux++;

                                            else if ((vjugadores[a].identificadorUsuario == idJugador2) && (vjugadores[a].plantado))
                                                aux++;
                                        }

                                        if (aux == 1) // Si solo se ha plantado un jugador
                                        {
                                            bzero(buffer, sizeof(buffer));
                                            sprintf(buffer, "+Ok. Esperando que finalice el otro jugador");
                                            send(i, buffer, sizeof(buffer), 0);
                                        }
                                        else if (aux == 2) // Si se han plantado los dos jugadores, comprobamos quien ha ganado
                                        {
                                            int sumaJugador1 = 0, sumaJugador2 = 0;
                                            string usuario1, usuario2;

                                            for (int a = 0; a < vjugadores.size(); a++)
                                            {
                                                if (vjugadores[a].identificadorUsuario == i)
                                                {
                                                    sumaJugador1 = vjugadores[a].suma;
                                                    usuario1 = vjugadores[a].usuario;
                                                }
                                                else if (vjugadores[a].identificadorUsuario == idJugador2)
                                                {
                                                    sumaJugador2 = vjugadores[a].suma;
                                                    usuario2 = vjugadores[a].usuario;
                                                }
                                            }

                                            // Han empatado los jugadores
                                            if ((sumaJugador1 == sumaJugador2) && (sumaJugador1 <= 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s y Jugador %s habéis empatado la partida", usuario1.c_str(), usuario2.c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s y Jugador %s habéis empatado la partida", usuario1.c_str(), usuario2.c_str());
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }
                                            // Jugador 2 ha ganado la partida y ninguno ha superado 21 puntos
                                            else if ((sumaJugador1 < sumaJugador2) && (sumaJugador1 <= 21) && (sumaJugador2 <= 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario2.c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario2.c_str());
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }
                                            // Jugador 1 ha ganado la partida y ninguno ha superado 21 puntos
                                            else if ((sumaJugador1 > sumaJugador2) && (sumaJugador1 <= 21) && (sumaJugador2 <= 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario1.c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario1.c_str());
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }
                                            // Jugador 1 ha ganado la partida porque el Jugador 2 ha superado los 21 puntos
                                            else if ((sumaJugador1 <= 21) && (sumaJugador2 > 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario1.c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario1.c_str());
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }
                                            // Jugador 2 ha ganado la partida porque el Jugador 1 ha superado los 21 puntos
                                            else if ((sumaJugador1 > 21) && (sumaJugador2 <= 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario2.c_str());
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. Jugador %s ha ganado la partida", usuario2.c_str());
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }
                                            // Ninguno ha ganado, los dos ha superado los 21 puntos
                                            else if ((sumaJugador1 > 21) && (sumaJugador2 > 21))
                                            {
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. No hay ganadores");
                                                send(i, buffer, sizeof(buffer), 0);
                                                bzero(buffer, sizeof(buffer));
                                                sprintf(buffer, "+Ok. No hay ganadores");
                                                send(idJugador2, buffer, sizeof(buffer), 0);
                                            }

                                            // Elimina a ambos jugadores de la partida
                                            eliminaJugadoresPartida(vjugadores, i, idJugador2, vpartidas, vbaraja);
                                        }
                                    }
                                    else if (estadoJugador != 4) // Si el jugador no ha iniciado una partida
                                    {
                                        bzero(buffer, sizeof(buffer));
                                        sprintf(buffer, "-ERR. No puedes plantarte sin antes iniciar partida.");
                                        send(i, buffer, sizeof(buffer), 0);
                                    }
                                }
                                else // Si el jugador no está logueado
                                {
                                    bzero(buffer, sizeof(buffer));
                                    sprintf(buffer, "-ERR. No puedes plantarte sin antes loguearte.");
                                    send(i, buffer, sizeof(buffer), 0);
                                }
                            }

                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            /* EL USUARIO INTRODUCE UN COMANDO QUE NO SON LOS ANTERIORES */
                            /*----------------------------------------------------------------------------------------------------------------------------------------*/
                            else
                            {
                                bzero(buffer, sizeof(buffer));
                                sprintf(buffer, "-ERR. No te permite enviar este mensaje");
                                send(i, buffer, sizeof(buffer), 0);
                            }
                        }
                        /*----------------------------------------------------------------------------------------------------------------------------------------*/
                        /* EL USUARIO INTRODUCE ctrl+c */
                        /*----------------------------------------------------------------------------------------------------------------------------------------*/
                        if (recibidos == 0)
                        {
                            int estadoJugador = 0;
                            // Mira el estado del jugador (si esta en una partida jugando)
                            for (int a = 0; a < vjugadores.size(); a++)
                            {
                                if (vjugadores[a].identificadorUsuario == i)
                                {
                                    estadoJugador = vjugadores[a].estado;
                                }
                            }

                            if (estadoJugador == 4) // Si el jugador esta en una partida
                            {
                                int idJugador2 = 0;
                                for (int h = 0; h < vpartidas.size(); h++)
                                {
                                    if (vpartidas[h].jugador1.identificadorUsuario == i)
                                    {
                                        idJugador2 = vpartidas[h].jugador2.identificadorUsuario;
                                    }
                                    else if (vpartidas[h].jugador2.identificadorUsuario == i)
                                    {
                                        idJugador2 = vpartidas[h].jugador1.identificadorUsuario;
                                    }
                                }
                                // Avisa al otro jugador de que se ha salido de la partida
                                bzero(buffer, sizeof(buffer));
                                sprintf(buffer, "+Ok. Tu oponente ha terminado la partida");
                                send(idJugador2, buffer, sizeof(buffer), 0);

                                // Elimina a ambos jugadores de la partida
                                eliminaJugadoresPartida(vjugadores, i, idJugador2, vpartidas, vbaraja);
                            }
                            else if (estadoJugador == 3)
                            {
                                // Elimina al jugador de la lista de espera
                                eliminaJugador(vjugadores, i, vpartidas, vbaraja);
                            }

                            salirCliente(i, &readfds, &numClientes, arrayClientes);
                        }
                    }
                }
            }
        }
    }

    close(sd);
    return 0;
}

void salirCliente(int socket, fd_set *readfds, int *numClientes, int arrayClientes[])
{
    printf("Cliente <%d> desconectado.\n", socket);

    char buffer[250];
    int j;

    close(socket);
    FD_CLR(socket, readfds);

    // Re-estructurar el array de clientes
    for (j = 0; j < (*numClientes) - 1; j++)
        if (arrayClientes[j] == socket)
            break;
    for (; j < (*numClientes) - 1; j++)
        (arrayClientes[j] = arrayClientes[j + 1]);

    (*numClientes)--;
}

void manejador(int signum)
{
    printf("\n-ERR. Se ha recibido la señal sigint. Para apagar el servidor introduzca SALIR.\n");
    signal(SIGINT, manejador);
}
